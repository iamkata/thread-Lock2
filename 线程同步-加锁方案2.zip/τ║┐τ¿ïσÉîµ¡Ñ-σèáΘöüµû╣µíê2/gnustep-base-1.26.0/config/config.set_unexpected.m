
#include "objc-common.g"

int main (void)
{
  objc_set_unexpected(0);
  return 0;
}
